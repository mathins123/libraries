AjaxMin.exe <FILE_NAME> -o <OUTPUT_FILE NAME>

- Help

AjaxMin.exe -?